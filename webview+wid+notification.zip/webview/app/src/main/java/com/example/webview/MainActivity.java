package com.example.webview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.os.Bundle;
import android.widget.RemoteViews;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    int count = 0;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        WebView webView = findViewById(R.id.WebViewer);
        WebSettings webSettings = webView.getSettings();
        webSettings.setSupportZoom(true);


        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);

        //알림 채널 만들기
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel notificationChannel = new NotificationChannel(
                    "alarm_channel_id",
                    "카운트 알람",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            notificationChannel.setDescription("알림 테스트!");
            notificationManager.createNotificationChannel(notificationChannel);
        }
        //테스트용 알림
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "alarm_channel_id")
                .setSmallIcon(R.drawable.notification_icon)
                .setContentTitle("카운트를 세고 있습니다.")
                .setStyle(new NotificationCompat.BigTextStyle().bigText("카운트 : "+count))
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setAutoCancel(false)
                .setOngoing(true)
                .setContentIntent(pendingIntent);


        //알림 실행 메니저
        NotificationManagerCompat makenotificationManager = NotificationManagerCompat.from(this);

        //주기마다 실행
        Timer timer = new Timer();
        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                //1초마다 실행
                makenotificationManager.notify(0, builder.setStyle(new NotificationCompat.BigTextStyle().bigText("카운트 : "+count)).build());
            }
        };
        timer.schedule(timerTask,0,1000);


        //webview 실행
        webView.loadUrl("file:///android_asset/webview.html");
        webSettings.setJavaScriptEnabled(true);
        webView.addJavascriptInterface(new WebAppInterface(this), "android");
    }

    public class WebAppInterface {
        Context mContext;
        int a = 0;

        /** Instantiate the interface and set the context */
        WebAppInterface(Context c) {
            mContext = c;
        }

        /** Show a toast from the web page */
        @JavascriptInterface
        public void showToast(String toast) {
            Toast.makeText(mContext, toast, Toast.LENGTH_SHORT).show();
        }
        @JavascriptInterface
        public void UpaButton(){
            a++;
            Toast.makeText(mContext, ""+a, Toast.LENGTH_SHORT).show();
        }

        @JavascriptInterface
        public void countPlus(){
            count++;
            Toast.makeText(mContext, "현재 카운트 : "+count, Toast.LENGTH_SHORT).show();
        }
        @JavascriptInterface
        public void countReset(){
            count = 0;
            Toast.makeText(mContext, "카운트 리셋!", Toast.LENGTH_SHORT).show();
        }
    }

}