package com.example.ctq_deenergy;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    double C_Energy = 0;//전력 사용량
    String C_unit = "Wh";
    double R_Energy = 0;//전력 절약량
    String R_unit = "Wh";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WebView webView = findViewById(R.id.WvMain);


        //webview 구간
        WebSettings webSettings = webView.getSettings();
        webSettings.setSupportZoom(true);

        webView.loadUrl("https://deenergy.seil-ctq.com/");
        webSettings.setJavaScriptEnabled(true);

        webView.addJavascriptInterface(new WebAppInterface(getApplicationContext()), "android");


        //알림(notification)구간
        //클릭시 띄울 pendingintent
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);


        //알림 채널 만들기
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel notificationChannel = new NotificationChannel(
                    "alarm_channel_id",
                    "전력 절약/사용량/경고",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            notificationChannel.setDescription("전력 절약/사용량 알림");
            notificationManager.createNotificationChannel(notificationChannel);
        }

        //전력 사용량 알림
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "alarm_channel_id")
                .setSmallIcon(R.drawable.ic_baseline_notibolt)
                .setContentTitle("전력 측정중")
                .setStyle(new NotificationCompat.BigTextStyle().bigText("전력 사용량 : "+C_Energy+C_unit+"\n전력 절약량 : "+R_Energy+R_unit))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(false)
                .setOngoing(true);
                //.setContentIntent(pendingIntent);

        //전력 사용량 경고
        NotificationCompat.Builder warnnoti = new NotificationCompat.Builder(this, "alarm_channel_id")
                .setSmallIcon(R.drawable.ic_baseline_notifiwarn)
                .setContentTitle("경고!")
                .setStyle(new NotificationCompat.BigTextStyle().bigText("전력을 "+C_Energy+C_unit +" 만큼 사용했습니다!"))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(false);

        //알림 실행 메니저
        NotificationManagerCompat makenotificationManager = NotificationManagerCompat.from(this);

        //주기마다 실행
        Timer timer = new Timer();//사용량 타이머
        Timer warntimer = new Timer();//경고 타이머

        //전력 사용량 갱신
        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                //1초마다 실행
                makenotificationManager.notify(0, builder.setStyle(new NotificationCompat.BigTextStyle()
                                                    .bigText("전력 사용량 : "+C_Energy+C_unit+"\n전력 절약량 : "+R_Energy+R_unit)).build());
                C_Energy++;
            }
        };

        //전력 사용 경고 갱신
        TimerTask warnTask = new TimerTask() {
            @Override
            public void run() {
                //20초마다 실행
                if (C_Energy >= 20)
                    makenotificationManager.notify(1, warnnoti.setStyle(new NotificationCompat.BigTextStyle()
                                                        .bigText("전력을 "+C_Energy+C_unit +" 만큼 사용했습니다!")).build());

            }
        };
        //scheduling
        timer.schedule(timerTask,0,1000);//전력 사용량 갱신
        warntimer.schedule(warnTask,0,20000);//전력 사용 경고 갱신


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        NotificationManagerCompat makenotificationManager = NotificationManagerCompat.from(this);
        makenotificationManager.cancelAll();
    }

    public class WebAppInterface {
        Context mContext;

        /** Instantiate the interface and set the context */
        WebAppInterface(Context c) {
            mContext = c;
        }

        /** Show a toast from the web page */
        @JavascriptInterface
        public void getReservedEnergy(double consumed_energy, String consumed_unit, double reserved_energy, String reserved_unit) {

            C_Energy = consumed_energy;
            C_unit = consumed_unit;
            R_Energy = reserved_energy;
            R_unit = reserved_unit;

        }
    }
}